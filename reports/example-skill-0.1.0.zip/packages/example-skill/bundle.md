# Skill Bundle: Example Skill

- id: example-skill
- version: 0.1.0
- summary: A starter skill that references repository authoring guidance.
- inputs: task, constraints
- outputs: context_bundle, report

## Skill Body

# Example Skill

## Purpose

Use this skill when a task needs repeatable repository maintenance with explicit assumptions and a compact execution plan.

## Operating Rules

- Load repository facts before editing or proposing changes.
- Use referenced knowledge documents to keep conventions consistent.
- Prefer small reusable building blocks over copying long instructions into every skill.

## Knowledge References

### Skill Authoring Guide
id: authoring-guide
path: knowledge\authoring-guide.md

# Skill Authoring Guide

Keep each skill short. Put shared rules, parsing logic, and packaging behavior in Python modules instead of duplicating them in markdown.

### Repository Maintenance Playbook
id: repo-playbook
path: knowledge\repo-playbook.md

# Repository Maintenance Playbook

Register external repositories in the workspace registry before using them. Default to read-only checks when building context or audits.
