# Example Skill

## Purpose

Use this skill when a task needs repeatable repository maintenance with explicit assumptions and a compact execution plan.

## Operating Rules

- Load repository facts before editing or proposing changes.
- Use referenced knowledge documents to keep conventions consistent.
- Prefer small reusable building blocks over copying long instructions into every skill.

