+++
id = "repo-playbook"
title = "Repository Maintenance Playbook"
source = "internal"
updated_at = "2026-03-20"
tags = ["repository", "operations"]
related_skills = ["example-skill"]
status = "active"
+++

# Repository Maintenance Playbook

Register external repositories in the workspace registry before using them. Default to read-only checks when building context or audits.

