+++
id = "authoring-guide"
title = "Skill Authoring Guide"
source = "internal"
updated_at = "2026-03-20"
tags = ["skills", "authoring"]
related_skills = ["example-skill"]
status = "active"
+++

# Skill Authoring Guide

Keep each skill short. Put shared rules, parsing logic, and packaging behavior in Python modules instead of duplicating them in markdown.

